@echo off
title Push Flower FL ke GitHub untuk Streamlit Cloud
echo =====================================================================
echo   🌸 AUTO-PUSH REPO KE GITHUB (UNTUK STREAMLIT CLOUD DEPLOYMENT)
echo =====================================================================
echo.
echo Pastikan Anda sudah membuat repository kosong di GitHub:
echo https://github.com/new
echo.
set /p REPO_URL="Masukkan URL Repository GitHub Anda (contoh: https://github.com/username/flower-fl.git): "

if "%REPO_URL%"=="" (
    echo Error: URL repository tidak boleh kosong!
    pause
    exit /b
)

echo.
echo [1/4] Menginisialisasi git repository lokal...
git init
git branch -M main

echo [2/4] Menambahkan semua file...
git add .

echo [3/4] Melakukan commit...
git commit -m "Deploy Flower Federated Learning Simulator on Streamlit Cloud"

echo [4/4] Menghubungkan remote dan push ke GitHub...
git remote remove origin >nul 2>&1
git remote add origin %REPO_URL%
git push -u origin main

echo.
echo =====================================================================
echo   SELESAI! File telah terunggah ke GitHub Anda.
echo   Sekarang buka: https://share.streamlit.io
echo   Klik 'New App' -^> Pilih repo tersebut -^> Klik 'Deploy!'
echo =====================================================================
pause
