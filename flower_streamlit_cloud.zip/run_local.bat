@echo off
title Menjalankan Flower FL Streamlit Dashboard...
echo ========================================================
echo   🌸 Menjalankan Flower FL Simulator di Streamlit
echo ========================================================
echo Memeriksa dependensi dan menjalankan streamlit...
python -m streamlit run streamlit_app.py
pause
